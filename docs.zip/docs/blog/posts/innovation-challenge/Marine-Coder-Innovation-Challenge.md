---
date: 2021-03-23
catagories:
  - Events
--- 

# Marine Coder Innovation Challenge

## Calling all MEFs...The time is now to bring together all your coding talent to create a micro-application in an accredited Marine Corps DevSecOps environment.  See [Software Innovation Challenge MARADMIN](https://www.marines.mil/News/Messages/Messages-Display/Article/2549693/solicitation-for-participation-in-the-marine-corps-inaugural-micro-application/) for details!
Situation: This MARADMIN serves as an announcement of the first micro- application development innovation challenge.  IC4 requests each MEF to assemble, and authorize the duty efforts of,<!-- more --> one Coding Team from their cadre of technically skilled personnel to research, engineer, test, and deploy a micro-software application that will either reduce operational friction, optimize workflow, increase Unit Readiness, or alleviate administrative burdens across any warfighting function.  MEF Coding Teams will be authorized to utilize Marine Corps resources such as time, equipment, and facilities. Furthermore, the MEF Coding Teams will utilize the Marine Corps Business Optimization Support Services (MCBOSS) Development-Security-Operations (DevSecOps) ecosystem to rapidly develop software in support of the challenge.  This challenge tests the theory that, given the right resources, talented Marines across the MOS spectrum can design and deliver software capabilities that can enable and expand efficiencies from tactical to strategic level.  IC4 recommends that the Marine Expeditionary Force Information Group take the lead within their respective MEF to assemble and lead the MEF's Coding Team in support of this challenge.
