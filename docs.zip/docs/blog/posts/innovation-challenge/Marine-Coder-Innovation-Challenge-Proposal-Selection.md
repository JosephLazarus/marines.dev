---
date: 2021-04-17
categories: 
 - Announcements
 - News
links:
 - blog/posts/innovation-challenge/Marine-Coder-Innovation-Challenge-Voting-Panel-Day.md
 - blog/posts/innovation-challenge/Marine-Coder-Innovation-Challenge.md
---

# Marine Coder Innovation Challenge Proposal Selection
## Four projects were selected for further development in the Marine Corps Business Operations Support Services (MCBOSS) accredited DevSecOps environment!
 The selected proposals are: 
  * I MEF: GCCS Reconciliation Tool
  * II MEF: Command Data Visualization Tool
  * III MEF: REDONKULATOR Logistics Planning Tool
  * MARFORRES: Predictive Maintenance Operations
<! - more -->
Each MEF team will begin a 90 day development evolution where they will learn how to: 
  * Plan and execute agile software development methodology
  * Achieve an Authority to Operate (ATO) through the Risk Management Framework (RMF) methodology
  * Use Git Flow and Trunk Based Development to effectively build and collaborate on a product as a team
  * Leverage a Platform as a Service (PaaS) to build containerized apps using a DevSecOps pipeline
  * Build a web hosted static site!
  * And much more!
