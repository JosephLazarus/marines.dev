---
date: 2020-09-30
categories: 
 - Announcements
 - News
tags:
 - Hackathon
---

# Naval Letter Hackathon
Marine Coders hosted its second hackathon to finalize the Naval Letter Format Generator Minimum Viable Product (MVP).  A team of (4) active duty Marines and (1) U.S. Citizen accomplished the following: <!-- more -->
* Features added to include the "Via," "Ref," and "Encl."
* Deployed the application to Platform One's production environment through a CI/CD pipeline.  Our application is now containerized is in compliance with the DoD DevSecOps Reference Design.  Thanks for the support, Jon!
  The application is now accessible here: 
[Naval Letter Format Generator](https://naval-letter.preprod.dsop.io/)

In addition to the work on the Naval Letter Format Generator, the team updated content and developed a plan to implement a subscription mailing list on the [Marine Coders static site](https://marines.dev).

![Marine Coders Naval Letter Format Hackathon](/assets/Naval Letter Hackathon 2.jpg){: .align-center}  
