# Learn something new!

## Great Resources for Learning Modern Software Development
Useful links to get you started - no federal endorsement intended or implied. Contact us to help point you in the right direction for your project.

### DoD Tools and Services
[Cloud.gov - Online PaaS with Sandbox](https://cloud.gov)

:   Offers a fast way for federal agencies to host and update websites, APIs, and other applications. Employees and contractors can focus on developing mission-critical applications, leaving server infrastructure management to us.

[Data.gov - Catalog of data related sources](https://data.gov)

:   Data, tools, and resources to conduct research, develop web and mobile applications, design data visualizations, and more.

[USWDS - The United States Web Design System](https://designsystem.digital.gov/)
:   A design system for the federal government. 

### Self Guided Courses for Zero to Hero
* [DigitalU - Air Force partnering with Udemy, PluralSight, and Udacity](http://digitalu.af.mil)
* [FreeCodeCamp](https://www.freecodecamp.org/)
* [App Academy Self Guided Bootcamp](https://open.appacademy.io/)
* [Derek Banas Youtube Channel](https://www.youtube.com/channel/UCwRXb5dUK4cvsHbx-rGzSgw)

### Methodology
* [Agile](https://software.af.mil/training/training-agile/)
* [Military SCRUM / Warfighter centered Design Courses - Center for Adaptive Warfighting](https://www.secnav.navy.mil/agility/Pages/caw.aspx)
* [DevOps](https://software.af.mil/training/devops/)
* [Microservices](https://software.af.mil/training/microservices/)

### Front End Web Frameworks
* [React - Offical Website](https://reactjs.org)
* [Vue.js - Official Website](https://vuejs.org/)
* [Angular - Official Website](https://angular.io)
* [Bootstrap - Offical Website](https://getbootstrap.com/)
* [Materialize - Official Website](https://materializecss.com/)

### Mobile
* [iOS for Beginners](https://www.raywenderlich.com/ios/paths/learn)
* [iOS Tutorial from Apple](https://developer.apple.com/library/archive/referencelibrary/GettingStarted/DevelopiOSAppsSwift/)
* [Android Studio](https://developer.android.com/studio)

## Back End

### API
* [Google API Design Standards](https://cloud.google.com/apis/design)
* [Azure RESTful web API Design](https://learn.microsoft.com/en-us/azure/architecture/best-practices/api-design)
* [RESTful API Standards and Design](https://restfulapi.net/)
### Web
* [Django Girls Tutorial](https://tutorial.djangogirls.org/en/)
* [Django Web Framework - Official Website](https://www.djangoproject.com/)
* [Django REST Framework - Official Website](https://www.django-rest-framework.org/)
* [Flask Tutorial - Real Python](https://realpython.com/tutorials/flask/)
* [Flask - Official Website](https://flask.palletsprojects.com/en/1.1.x/)

### Daily Practice
* [LeetCode](https://leetcode.com/)

### Transitioning Service Members
* [Operation Code](https://operationcode.org)
* [Microsoft Software Systems Academy - Now Free!](https://military.microsoft.com/programs/microsoft-software-systems-academy/)

### Platforms & Infrastructure
* [Kubernetes - AF Overview](https://software.af.mil/training/kubernetes/)
* [Kubernetes - Official Website](https://kubernetes.io)
* [Ansible Learning](https://www.ansible.com/resources/get-started)
* [Terraform - Official Website](https://www.terraform.io/)
* [AWS Cloud Practitioner Course](https://aws.amazon.com/training/government/us/)

### Data Exploration
* [Anaconda Data Science Suite - Official Website](https://www.anaconda.com/)
* [How to use Jupyter Notebook](https://www.dataquest.io/blog/jupyter-notebook-tutorial/)
* [Getting Started with Pandas](https://riptutorial.com/pandas)
* [Getting Started with Numpy](https://www.datacamp.com/community/tutorials/python-numpy-tutorial)
* [Getting Started with Matplotlib](https://www.datacamp.com/community/tutorials/matplotlib-tutorial-python)

### Tanzu
* [Kube Academy](https://kube.academy/)
* [Open Source Kubernetes Platform | Tanzu Community Edition](https://tanzucommunityedition.io/)
* [VMware Tanzu Developer Center](https://tanzu.vmware.com/developer/)
* [ModernApps Learning by VMware Tanzu Home](https://modernapps.ninja/)